﻿namespace Medicines.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-FI5CDKM\SQLEXPRESS;Database=Medicines;Integrated Security=True;Encrypt=False";
    }
}
