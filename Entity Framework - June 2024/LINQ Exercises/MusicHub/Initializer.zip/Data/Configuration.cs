﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-FI5CDKM\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
