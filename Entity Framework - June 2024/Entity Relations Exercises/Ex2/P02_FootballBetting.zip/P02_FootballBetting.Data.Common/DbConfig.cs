﻿namespace P02_FootballBetting.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionString =
            @"Server=DESKTOP-FI5CDKM\SQLEXPRESS;Database=Bet388;Integrated Security=true;Encrypt=false;";
    }
}