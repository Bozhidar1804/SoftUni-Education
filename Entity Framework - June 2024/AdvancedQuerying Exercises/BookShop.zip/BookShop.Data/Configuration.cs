﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-FI5CDKM\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
