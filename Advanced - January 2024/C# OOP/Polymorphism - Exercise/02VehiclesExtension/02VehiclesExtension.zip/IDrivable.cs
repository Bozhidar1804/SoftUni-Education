﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01Vehicles
{
    public interface IDrivable
    {
        void Drive(double distance);
    }
}
