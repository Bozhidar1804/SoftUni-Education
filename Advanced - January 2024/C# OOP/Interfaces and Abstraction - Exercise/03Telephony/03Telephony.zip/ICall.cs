﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03Telephony
{
    public interface ICall
    {
        void Call(string phoneNumber);
    }
}
