﻿namespace AuthorProblem
{
    [Author("Bozhidar")]
    public class StartUp
    {
        [Author("Georgi")]
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}